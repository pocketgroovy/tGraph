package roadgraph;

import java.util.ArrayList;
import java.util.List;

import geography.GeographicPoint;

public class Node {
	private GeographicPoint _nodePosition;
	private List<MapEdge> _edges;

	int _numOutdegree;
		
	public Node(GeographicPoint from){
		_nodePosition = from;
		_edges = new ArrayList<>();
	}
	
	// add to list of edge(or neighbor node position, road name, road type and length information)
	public boolean addEdge(GeographicPoint from,GeographicPoint to, String roadName, String roadType, double length){
		MapEdge edge = new MapEdge(from, to, roadName, roadType, length);
		if(!_edges.contains(edge)){
			_edges.add(edge);
			_numOutdegree++;
			return true;
		}
		return false;
	}
	
	// neighbor node count
	public int getNumOutdegree(){
		return _numOutdegree;
	}
	
	public GeographicPoint getNodePosition(){
		return _nodePosition;
	}
	
	// same as neighbors
	public List<MapEdge> getEdges(){
		return new ArrayList<MapEdge>(_edges); // return a copy of the data
	}
	
	@Override
    public int hashCode() {
        long bits = java.lang.Double.doubleToLongBits(_nodePosition.getX());
        bits ^= java.lang.Double.doubleToLongBits(_nodePosition.getY()) * 31;
        return (((int) bits) ^ ((int) (bits >> 32)));
    }

    /**
     * Determines whether or not two  are equal. Two instances of
     * <code>Node</code> are equal if the values of their
     * <code>nodePositions</code> are the same.
     * @param obj an object to be compared with this <code>Node</code>
     * @return <code>true</code> if the object to be compared is
     *         an instance of <code>Node</code> and has
     *         the same values; <code>false</code> otherwise.
     * @since 1.2
     */
	@Override
    public boolean equals(Object obj) {
    	if(obj instanceof Node){
    		Node node = (Node)obj;
	            return (_nodePosition.equals(node.getNodePosition()));
        }
        return super.equals(obj);
    }
	
	@Override
	public String toString()
    {
    	return _nodePosition.toString();
    }
}
