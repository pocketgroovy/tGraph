package roadgraph;

import geography.GeographicPoint;

public class MapEdge {
	GeographicPoint _endPoint; 
	String _roadName;
	String _roadType;
	double _length;
	
	public MapEdge(GeographicPoint to, String roadName, String roadType, double length){
		_endPoint = to;
		_roadName = roadName;
		_roadType = roadType;
		_length = length;
	}
	
	public GeographicPoint getEndPoint(){
		return _endPoint;
	}
	
	public String getRoadName(){
		return _roadName;
	}
	
	public String getRoadType(){
		return _roadType;
	}
	
	public double getLength(){
		return _length;
	}
	
	@Override
    public int hashCode() {
        long bits = java.lang.Double.doubleToLongBits(_endPoint.getX());
        bits ^= java.lang.Double.doubleToLongBits(_endPoint.getY()) * 31;
        return (((int) bits) ^ ((int) (bits >> 32)));
    }

    /**
     * Determines whether or not two  are equal. Two instances of
     * <code>MapEdge</code> are equal if the values of their
     * <code>end  point</code> and <code>road name</code> and
     * <code>road type </code> and <code>length</code> are the same.
     * @param obj an object to be compared with this <code>MapEdge</code>
     * @return <code>true</code> if the object to be compared is
     *         an instance of <code>MapEdge</code> and has
     *         the same values; <code>false</code> otherwise.
     * @since 1.2
     */
	@Override
    public boolean equals(Object obj) {
    	if(obj instanceof MapEdge){
    		MapEdge edge = (MapEdge)obj;
	            return (_endPoint.equals(edge.getEndPoint()) && _roadName.equals(edge.getRoadName()) &&
	            		_roadType.equals(edge.getRoadType())&& _length == edge.getLength());
        }
        return super.equals(obj);
    }
}
